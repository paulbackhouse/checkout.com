# swagger-java-client

## Requirements

Building the API client library requires [Maven](https://maven.apache.org/) to be installed.

## Installation

To install the API client library to your local Maven repository, simply execute:

```shell
mvn install
```

To deploy it to a remote Maven repository instead, configure the settings of the repository and execute:

```shell
mvn deploy
```

Refer to the [official documentation](https://maven.apache.org/plugins/maven-deploy-plugin/usage.html) for more information.

### Maven users

Add this dependency to your project's POM:

```xml
<dependency>
    <groupId>io.swagger</groupId>
    <artifactId>swagger-java-client</artifactId>
    <version>1.0.0</version>
    <scope>compile</scope>
</dependency>
```

### Gradle users

Add this dependency to your project's build file:

```groovy
compile "io.swagger:swagger-java-client:1.0.0"
```

### Others

At first generate the JAR by executing:

    mvn package

Then manually install the following JARs:

* target/swagger-java-client-1.0.0.jar
* target/lib/*.jar

## Getting Started

Please follow the [installation](#installation) instruction and execute the following Java code:

```java

import io.swagger.client.*;
import io.swagger.client.auth.*;
import io.swagger.client.model.*;
import io.swagger.client.api.CartApi;

import java.io.File;
import java.util.*;

public class CartApiExample {

    public static void main(String[] args) {
        
        CartApi apiInstance = new CartApi();
        UUID cartId = new UUID(); // UUID | 
        Integer productId = 56; // Integer | 
        String version = "version_example"; // String | 
        try {
            apiInstance.apiVversionCartByCartIdByProductIdDelete(cartId, productId, version);
        } catch (ApiException e) {
            System.err.println("Exception when calling CartApi#apiVversionCartByCartIdByProductIdDelete");
            e.printStackTrace();
        }
    }
}

```

## Documentation for API Endpoints

All URIs are relative to *https://localhost*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*CartApi* | [**apiVversionCartByCartIdByProductIdDelete**](docs/CartApi.md#apiVversionCartByCartIdByProductIdDelete) | **DELETE** /api/v{version}/Cart/{cartId}/{productId} | 
*CartApi* | [**apiVversionCartByCartIdDelete**](docs/CartApi.md#apiVversionCartByCartIdDelete) | **DELETE** /api/v{version}/Cart/{cartId} | 
*CartApi* | [**apiVversionCartByCartIdGet**](docs/CartApi.md#apiVversionCartByCartIdGet) | **GET** /api/v{version}/Cart/{cartId} | 
*CartApi* | [**apiVversionCartPut**](docs/CartApi.md#apiVversionCartPut) | **PUT** /api/v{version}/Cart | 
*CountriesApi* | [**apiVversionCountriesByCountryIdGet**](docs/CountriesApi.md#apiVversionCountriesByCountryIdGet) | **GET** /api/v{version}/Countries/{countryId} | 
*CountriesApi* | [**apiVversionCountriesGet**](docs/CountriesApi.md#apiVversionCountriesGet) | **GET** /api/v{version}/Countries | 
*ProductsApi* | [**apiVversionProductsByCountryIdGet**](docs/ProductsApi.md#apiVversionProductsByCountryIdGet) | **GET** /api/v{version}/Products/{countryId} | 
*ProductsApi* | [**apiVversionProductsByProductIdGet**](docs/ProductsApi.md#apiVversionProductsByProductIdGet) | **GET** /api/v{version}/Products/{productId} | 


## Documentation for Models

 - [CartDto](docs/CartDto.md)
 - [CartProductDto](docs/CartProductDto.md)
 - [CountryDto](docs/CountryDto.md)
 - [ProductDto](docs/ProductDto.md)


## Documentation for Authorization

All endpoints do not require authorization.
Authentication schemes defined for the API:

## Recommendation

It's recommended to create an instance of `ApiClient` per thread in a multithreaded environment to avoid any potential issues.

## Author

paul.k.backhouse@gmail.com

