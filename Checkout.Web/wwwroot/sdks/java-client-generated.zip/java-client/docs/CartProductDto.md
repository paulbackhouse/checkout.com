
# CartProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productName** | **String** |  |  [optional]
**productCode** | **String** |  |  [optional]
**countryIsoCode** | **String** |  |  [optional]
**netPrice** | **Double** |  |  [optional]
**totalNetPrice** | **Double** |  |  [optional]
**totalNetPriceFormatted** | **String** |  |  [optional]
**taxAmount** | **Double** |  |  [optional]
**taxAmountFormatted** | **String** |  |  [optional]
**totalTax** | **Double** |  |  [optional]
**totalTaxFormatted** | **String** |  |  [optional]
**totalGrossPrice** | **Double** |  |  [optional]
**totalGrossPriceFormatted** | **String** |  |  [optional]
**cartId** | [**UUID**](UUID.md) | Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty &#x3D; 00000000-0000-0000-0000-000000000000) |  [optional]
**countryId** | **Integer** | Country the cart item relates to |  [optional]
**productId** | **Integer** | Cart item (product) to add/update |  [optional]
**qty** | **Integer** | the quantity to add/update for a given cart item (product) |  [optional]



