
# CartProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**countryIsoCode** | **String** |  |  [optional]
**netPrice** | **Double** |  |  [optional]
**totalNetPrice** | **Double** |  |  [optional]
**totalNetPriceFormatted** | **String** |  |  [optional]
**taxAmount** | **Double** |  |  [optional]
**taxAmountFormatted** | **String** |  |  [optional]
**totalTax** | **Double** |  |  [optional]
**totalTaxFormatted** | **String** |  |  [optional]
**totalGrossPrice** | **Double** |  |  [optional]
**totalGrossPriceFormatted** | **String** |  |  [optional]
**cartId** | [**UUID**](UUID.md) |  |  [optional]
**countryId** | **Integer** |  |  [optional]
**productId** | **Integer** |  |  [optional]
**qty** | **Integer** |  |  [optional]



