# CountriesApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionCountriesByCountryIdGet**](CountriesApi.md#apiVversionCountriesByCountryIdGet) | **GET** /api/v{version}/Countries/{countryId} | Gets a country by a given countryId
[**apiVversionCountriesGet**](CountriesApi.md#apiVversionCountriesGet) | **GET** /api/v{version}/Countries | Gets a collection of countries available for order process


<a name="apiVversionCountriesByCountryIdGet"></a>
# **apiVversionCountriesByCountryIdGet**
> CountryDto apiVversionCountriesByCountryIdGet(countryId, version)

Gets a country by a given countryId

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CountriesApi;


CountriesApi apiInstance = new CountriesApi();
Integer countryId = 56; // Integer | A given country Id to search for
String version = "version_example"; // String | 
try {
    CountryDto result = apiInstance.apiVversionCountriesByCountryIdGet(countryId, version);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CountriesApi#apiVversionCountriesByCountryIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **countryId** | **Integer**| A given country Id to search for |
 **version** | **String**|  |

### Return type

[**CountryDto**](CountryDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

<a name="apiVversionCountriesGet"></a>
# **apiVversionCountriesGet**
> List&lt;CountryDto&gt; apiVversionCountriesGet(version)

Gets a collection of countries available for order process

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CountriesApi;


CountriesApi apiInstance = new CountriesApi();
String version = "version_example"; // String | 
try {
    List<CountryDto> result = apiInstance.apiVversionCountriesGet(version);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CountriesApi#apiVversionCountriesGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **String**|  |

### Return type

[**List&lt;CountryDto&gt;**](CountryDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

