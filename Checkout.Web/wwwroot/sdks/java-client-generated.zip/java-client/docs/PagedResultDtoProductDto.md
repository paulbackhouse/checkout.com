
# PagedResultDtoProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**List&lt;ProductDto&gt;**](ProductDto.md) |  |  [optional]
**pager** | [**PagerDto**](PagerDto.md) |  |  [optional]



