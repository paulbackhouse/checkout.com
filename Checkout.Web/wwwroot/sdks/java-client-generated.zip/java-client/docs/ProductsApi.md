# ProductsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionProductsByCountryIdGet**](ProductsApi.md#apiVversionProductsByCountryIdGet) | **GET** /api/v{version}/Products/{countryId} | 
[**apiVversionProductsByProductIdGet**](ProductsApi.md#apiVversionProductsByProductIdGet) | **GET** /api/v{version}/Products/{productId} | 


<a name="apiVversionProductsByCountryIdGet"></a>
# **apiVversionProductsByCountryIdGet**
> List&lt;ProductDto&gt; apiVversionProductsByCountryIdGet(countryId, version, pageIndex, pageSize)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProductsApi;


ProductsApi apiInstance = new ProductsApi();
Integer countryId = 56; // Integer | 
String version = "version_example"; // String | 
Integer pageIndex = 56; // Integer | 
Integer pageSize = 56; // Integer | 
try {
    List<ProductDto> result = apiInstance.apiVversionProductsByCountryIdGet(countryId, version, pageIndex, pageSize);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductsApi#apiVversionProductsByCountryIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **countryId** | **Integer**|  |
 **version** | **String**|  |
 **pageIndex** | **Integer**|  | [optional]
 **pageSize** | **Integer**|  | [optional]

### Return type

[**List&lt;ProductDto&gt;**](ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

<a name="apiVversionProductsByProductIdGet"></a>
# **apiVversionProductsByProductIdGet**
> ProductDto apiVversionProductsByProductIdGet(productId, version)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProductsApi;


ProductsApi apiInstance = new ProductsApi();
Integer productId = 56; // Integer | 
String version = "version_example"; // String | 
try {
    ProductDto result = apiInstance.apiVversionProductsByProductIdGet(productId, version);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductsApi#apiVversionProductsByProductIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productId** | **Integer**|  |
 **version** | **String**|  |

### Return type

[**ProductDto**](ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

