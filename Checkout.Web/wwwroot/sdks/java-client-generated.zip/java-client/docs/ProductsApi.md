# ProductsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionProductsByProductIdGet**](ProductsApi.md#apiVversionProductsByProductIdGet) | **GET** /api/v{version}/Products/{productId} | Gets a product by a given productId
[**apiVversionProductsGet**](ProductsApi.md#apiVversionProductsGet) | **GET** /api/v{version}/Products | Gets a collection of products available for a given countryId


<a name="apiVversionProductsByProductIdGet"></a>
# **apiVversionProductsByProductIdGet**
> ProductDto apiVversionProductsByProductIdGet(productId, version)

Gets a product by a given productId

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProductsApi;


ProductsApi apiInstance = new ProductsApi();
Integer productId = 56; // Integer | Id to query for
String version = "version_example"; // String | 
try {
    ProductDto result = apiInstance.apiVversionProductsByProductIdGet(productId, version);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductsApi#apiVversionProductsByProductIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productId** | **Integer**| Id to query for |
 **version** | **String**|  |

### Return type

[**ProductDto**](ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

<a name="apiVversionProductsGet"></a>
# **apiVversionProductsGet**
> PagedResultDtoProductDto apiVversionProductsGet(version, countryId, pageIndex, pageSize)

Gets a collection of products available for a given countryId

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ProductsApi;


ProductsApi apiInstance = new ProductsApi();
String version = "version_example"; // String | 
Integer countryId = 56; // Integer | Required. A countryId to request products for
Integer pageIndex = 56; // Integer | Zero based index querystring parameter requesting page. i.e first page = 0
Integer pageSize = 56; // Integer | Page size querystring parameter required
try {
    PagedResultDtoProductDto result = apiInstance.apiVversionProductsGet(version, countryId, pageIndex, pageSize);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ProductsApi#apiVversionProductsGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **String**|  |
 **countryId** | **Integer**| Required. A countryId to request products for | [optional]
 **pageIndex** | **Integer**| Zero based index querystring parameter requesting page. i.e first page &#x3D; 0 | [optional]
 **pageSize** | **Integer**| Page size querystring parameter required | [optional]

### Return type

[**PagedResultDtoProductDto**](PagedResultDtoProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

