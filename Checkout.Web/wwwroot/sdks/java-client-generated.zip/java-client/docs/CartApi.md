# CartApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionCartByCartIdByProductIdDelete**](CartApi.md#apiVversionCartByCartIdByProductIdDelete) | **DELETE** /api/v{version}/Cart/{cartId}/{productId} | 
[**apiVversionCartByCartIdDelete**](CartApi.md#apiVversionCartByCartIdDelete) | **DELETE** /api/v{version}/Cart/{cartId} | 
[**apiVversionCartByCartIdGet**](CartApi.md#apiVversionCartByCartIdGet) | **GET** /api/v{version}/Cart/{cartId} | 
[**apiVversionCartPut**](CartApi.md#apiVversionCartPut) | **PUT** /api/v{version}/Cart | 


<a name="apiVversionCartByCartIdByProductIdDelete"></a>
# **apiVversionCartByCartIdByProductIdDelete**
> apiVversionCartByCartIdByProductIdDelete(cartId, productId, version)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CartApi;


CartApi apiInstance = new CartApi();
UUID cartId = new UUID(); // UUID | 
Integer productId = 56; // Integer | 
String version = "version_example"; // String | 
try {
    apiInstance.apiVversionCartByCartIdByProductIdDelete(cartId, productId, version);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#apiVversionCartByCartIdByProductIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartId** | [**UUID**](.md)|  |
 **productId** | **Integer**|  |
 **version** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="apiVversionCartByCartIdDelete"></a>
# **apiVversionCartByCartIdDelete**
> apiVversionCartByCartIdDelete(cartId, version)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CartApi;


CartApi apiInstance = new CartApi();
UUID cartId = new UUID(); // UUID | 
String version = "version_example"; // String | 
try {
    apiInstance.apiVversionCartByCartIdDelete(cartId, version);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#apiVversionCartByCartIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartId** | [**UUID**](.md)|  |
 **version** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="apiVversionCartByCartIdGet"></a>
# **apiVversionCartByCartIdGet**
> CartDto apiVversionCartByCartIdGet(cartId, version)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CartApi;


CartApi apiInstance = new CartApi();
UUID cartId = new UUID(); // UUID | 
String version = "version_example"; // String | 
try {
    CartDto result = apiInstance.apiVversionCartByCartIdGet(cartId, version);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#apiVversionCartByCartIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartId** | [**UUID**](.md)|  |
 **version** | **String**|  |

### Return type

[**CartDto**](CartDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

<a name="apiVversionCartPut"></a>
# **apiVversionCartPut**
> CartProductDto apiVversionCartPut(version, cartId, countryId, productId, qty)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CartApi;


CartApi apiInstance = new CartApi();
String version = "version_example"; // String | 
UUID cartId = new UUID(); // UUID | 
Integer countryId = 56; // Integer | 
Integer productId = 56; // Integer | 
Integer qty = 56; // Integer | 
try {
    CartProductDto result = apiInstance.apiVversionCartPut(version, cartId, countryId, productId, qty);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#apiVversionCartPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **String**|  |
 **cartId** | [**UUID**](.md)|  | [optional]
 **countryId** | **Integer**|  | [optional]
 **productId** | **Integer**|  | [optional]
 **qty** | **Integer**|  | [optional]

### Return type

[**CartProductDto**](CartProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

