# CartApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionCartByCartIdByProductIdDelete**](CartApi.md#apiVversionCartByCartIdByProductIdDelete) | **DELETE** /api/v{version}/Cart/{cartId}/{productId} | Removes a cart item for a given cartId and productId
[**apiVversionCartByCartIdDelete**](CartApi.md#apiVversionCartByCartIdDelete) | **DELETE** /api/v{version}/Cart/{cartId} | Removes and instance of a cart object and associated items
[**apiVversionCartByCartIdGet**](CartApi.md#apiVversionCartByCartIdGet) | **GET** /api/v{version}/Cart/{cartId} | Gets a cart for a given Cart Id reference.
[**apiVversionCartPut**](CartApi.md#apiVversionCartPut) | **PUT** /api/v{version}/Cart | Adds an item to a cart. A new cart is created if cartId is not specified on the item


<a name="apiVversionCartByCartIdByProductIdDelete"></a>
# **apiVversionCartByCartIdByProductIdDelete**
> apiVversionCartByCartIdByProductIdDelete(cartId, productId, version)

Removes a cart item for a given cartId and productId

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CartApi;


CartApi apiInstance = new CartApi();
UUID cartId = new UUID(); // UUID | CartId reference to delete a product against
Integer productId = 56; // Integer | ProductId reference to delete from a given cartId reference
String version = "version_example"; // String | 
try {
    apiInstance.apiVversionCartByCartIdByProductIdDelete(cartId, productId, version);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#apiVversionCartByCartIdByProductIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartId** | [**UUID**](.md)| CartId reference to delete a product against |
 **productId** | **Integer**| ProductId reference to delete from a given cartId reference |
 **version** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="apiVversionCartByCartIdDelete"></a>
# **apiVversionCartByCartIdDelete**
> apiVversionCartByCartIdDelete(cartId, version)

Removes and instance of a cart object and associated items

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CartApi;


CartApi apiInstance = new CartApi();
UUID cartId = new UUID(); // UUID | Id reference to delete all items and cart
String version = "version_example"; // String | 
try {
    apiInstance.apiVversionCartByCartIdDelete(cartId, version);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#apiVversionCartByCartIdDelete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartId** | [**UUID**](.md)| Id reference to delete all items and cart |
 **version** | **String**|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="apiVversionCartByCartIdGet"></a>
# **apiVversionCartByCartIdGet**
> CartDto apiVversionCartByCartIdGet(cartId, version)

Gets a cart for a given Cart Id reference.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CartApi;


CartApi apiInstance = new CartApi();
UUID cartId = new UUID(); // UUID | string. Unique identifier of a cart
String version = "version_example"; // String | 
try {
    CartDto result = apiInstance.apiVversionCartByCartIdGet(cartId, version);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#apiVversionCartByCartIdGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartId** | [**UUID**](.md)| string. Unique identifier of a cart |
 **version** | **String**|  |

### Return type

[**CartDto**](CartDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

<a name="apiVversionCartPut"></a>
# **apiVversionCartPut**
> CartProductDto apiVversionCartPut(version, cartId, countryId, productId, qty)

Adds an item to a cart. A new cart is created if cartId is not specified on the item

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CartApi;


CartApi apiInstance = new CartApi();
String version = "version_example"; // String | 
UUID cartId = new UUID(); // UUID | Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty = 00000000-0000-0000-0000-000000000000)
Integer countryId = 56; // Integer | Country the cart item relates to
Integer productId = 56; // Integer | Cart item (product) to add/update
Integer qty = 56; // Integer | the quantity to add/update for a given cart item (product)
try {
    CartProductDto result = apiInstance.apiVversionCartPut(version, cartId, countryId, productId, qty);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#apiVversionCartPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **String**|  |
 **cartId** | [**UUID**](.md)| Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty &#x3D; 00000000-0000-0000-0000-000000000000) | [optional]
 **countryId** | **Integer**| Country the cart item relates to | [optional]
 **productId** | **Integer**| Cart item (product) to add/update | [optional]
 **qty** | **Integer**| the quantity to add/update for a given cart item (product) | [optional]

### Return type

[**CartProductDto**](CartProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

