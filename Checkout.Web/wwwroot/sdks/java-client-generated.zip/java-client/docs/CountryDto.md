
# CountryDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**isoCode** | **String** |  | 
**currencySymbol** | **String** |  |  [optional]
**currency** | **String** |  |  [optional]
**tax** | **Double** |  |  [optional]
**taxFormatted** | **String** |  |  [optional]
**isDefault** | **Boolean** |  |  [optional]
**isActive** | **Boolean** |  |  [optional]
**id** | **Integer** |  |  [optional]



