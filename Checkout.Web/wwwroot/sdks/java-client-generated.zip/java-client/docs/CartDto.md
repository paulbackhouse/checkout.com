
# CartDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cartId** | [**UUID**](UUID.md) |  |  [optional]
**countryId** | **Integer** |  |  [optional]
**countryIsoCode** | **String** |  |  [optional]
**items** | [**List&lt;CartProductDto&gt;**](CartProductDto.md) |  |  [optional]
**totalNetPrice** | **Double** |  |  [optional]
**totalNetPriceFormatted** | **String** |  |  [optional]
**totalTax** | **Double** |  |  [optional]
**totalTaxFormatted** | **String** |  |  [optional]
**totalGrossPrice** | **Double** |  |  [optional]
**totalGrossPriceFormatted** | **String** |  |  [optional]



