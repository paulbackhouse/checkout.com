
# CartDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cartId** | [**UUID**](UUID.md) | An Id of an exiting cart |  [optional]
**countryId** | **Integer** | The country Id this cart relates to |  [optional]
**countryIsoCode** | **String** | The country ISO code the cart is valid for |  [optional]
**items** | [**List&lt;CartProductDto&gt;**](CartProductDto.md) |  |  [optional]
**totalNetPrice** | **Double** |  |  [optional]
**totalNetPriceFormatted** | **String** |  |  [optional]
**totalTax** | **Double** |  |  [optional]
**totalTaxFormatted** | **String** |  |  [optional]
**totalGrossPrice** | **Double** |  |  [optional]
**totalGrossPriceFormatted** | **String** |  |  [optional]



