
# ProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  | 
**shortDescription** | **String** |  | 
**netPrice** | **Double** |  |  [optional]
**netPriceFormatted** | **String** |  |  [optional]
**country** | [**CountryDto**](CountryDto.md) |  | 
**taxAmount** | **Double** |  |  [optional]
**taxAmountFormatted** | **String** |  |  [optional]
**id** | **Integer** |  |  [optional]
**name** | **String** |  |  [optional]



