
# PagerDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **Long** |  |  [optional]
**pageNumber** | **Integer** |  |  [optional]
**pageCount** | **Integer** |  |  [optional]
**pageIndex** | **Integer** |  |  [optional]
**pageSize** | **Integer** |  |  [optional]
**isLastPage** | **Boolean** |  |  [optional]
**isFirstPage** | **Boolean** |  |  [optional]



