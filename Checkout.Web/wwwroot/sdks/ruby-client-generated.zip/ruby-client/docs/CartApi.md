# SwaggerClient::CartApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_vversion_cart_by_cart_id_by_product_id_delete**](CartApi.md#api_vversion_cart_by_cart_id_by_product_id_delete) | **DELETE** /api/v{version}/Cart/{cartId}/{productId} | 
[**api_vversion_cart_by_cart_id_delete**](CartApi.md#api_vversion_cart_by_cart_id_delete) | **DELETE** /api/v{version}/Cart/{cartId} | 
[**api_vversion_cart_by_cart_id_get**](CartApi.md#api_vversion_cart_by_cart_id_get) | **GET** /api/v{version}/Cart/{cartId} | 
[**api_vversion_cart_put**](CartApi.md#api_vversion_cart_put) | **PUT** /api/v{version}/Cart | 


# **api_vversion_cart_by_cart_id_by_product_id_delete**
> api_vversion_cart_by_cart_id_by_product_id_delete(cart_id, product_id, version)



### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CartApi.new

cart_id = "cart_id_example" # String | 

product_id = 56 # Integer | 

version = "version_example" # String | 


begin
  api_instance.api_vversion_cart_by_cart_id_by_product_id_delete(cart_id, product_id, version)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartApi->api_vversion_cart_by_cart_id_by_product_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**String**](.md)|  | 
 **product_id** | **Integer**|  | 
 **version** | **String**|  | 

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined



# **api_vversion_cart_by_cart_id_delete**
> api_vversion_cart_by_cart_id_delete(cart_id, version)



### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CartApi.new

cart_id = "cart_id_example" # String | 

version = "version_example" # String | 


begin
  api_instance.api_vversion_cart_by_cart_id_delete(cart_id, version)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartApi->api_vversion_cart_by_cart_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**String**](.md)|  | 
 **version** | **String**|  | 

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined



# **api_vversion_cart_by_cart_id_get**
> CartDto api_vversion_cart_by_cart_id_get(cart_id, version)



### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CartApi.new

cart_id = "cart_id_example" # String | 

version = "version_example" # String | 


begin
  result = api_instance.api_vversion_cart_by_cart_id_get(cart_id, version)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartApi->api_vversion_cart_by_cart_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**String**](.md)|  | 
 **version** | **String**|  | 

### Return type

[**CartDto**](CartDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0



# **api_vversion_cart_put**
> CartProductDto api_vversion_cart_put(version, opts)



### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CartApi.new

version = "version_example" # String | 

opts = { 
  cart_id: "cart_id_example", # String | 
  country_id: 56, # Integer | 
  product_id: 56, # Integer | 
  qty: 56 # Integer | 
}

begin
  result = api_instance.api_vversion_cart_put(version, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartApi->api_vversion_cart_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **String**|  | 
 **cart_id** | [**String**](.md)|  | [optional] 
 **country_id** | **Integer**|  | [optional] 
 **product_id** | **Integer**|  | [optional] 
 **qty** | **Integer**|  | [optional] 

### Return type

[**CartProductDto**](CartProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0



