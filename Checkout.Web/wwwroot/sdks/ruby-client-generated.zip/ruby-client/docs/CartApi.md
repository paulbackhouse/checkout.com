# SwaggerClient::CartApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_vversion_cart_by_cart_id_by_product_id_delete**](CartApi.md#api_vversion_cart_by_cart_id_by_product_id_delete) | **DELETE** /api/v{version}/Cart/{cartId}/{productId} | Removes a cart item for a given cartId and productId
[**api_vversion_cart_by_cart_id_delete**](CartApi.md#api_vversion_cart_by_cart_id_delete) | **DELETE** /api/v{version}/Cart/{cartId} | Removes and instance of a cart object and associated items
[**api_vversion_cart_by_cart_id_get**](CartApi.md#api_vversion_cart_by_cart_id_get) | **GET** /api/v{version}/Cart/{cartId} | Gets a cart for a given Cart Id reference.
[**api_vversion_cart_put**](CartApi.md#api_vversion_cart_put) | **PUT** /api/v{version}/Cart | Adds an item to a cart. A new cart is created if cartId is not specified on the item


# **api_vversion_cart_by_cart_id_by_product_id_delete**
> api_vversion_cart_by_cart_id_by_product_id_delete(cart_id, product_id, version)

Removes a cart item for a given cartId and productId

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CartApi.new

cart_id = "cart_id_example" # String | CartId reference to delete a product against

product_id = 56 # Integer | ProductId reference to delete from a given cartId reference

version = "version_example" # String | 


begin
  #Removes a cart item for a given cartId and productId
  api_instance.api_vversion_cart_by_cart_id_by_product_id_delete(cart_id, product_id, version)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartApi->api_vversion_cart_by_cart_id_by_product_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**String**](.md)| CartId reference to delete a product against | 
 **product_id** | **Integer**| ProductId reference to delete from a given cartId reference | 
 **version** | **String**|  | 

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined



# **api_vversion_cart_by_cart_id_delete**
> api_vversion_cart_by_cart_id_delete(cart_id, version)

Removes and instance of a cart object and associated items

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CartApi.new

cart_id = "cart_id_example" # String | Id reference to delete all items and cart

version = "version_example" # String | 


begin
  #Removes and instance of a cart object and associated items
  api_instance.api_vversion_cart_by_cart_id_delete(cart_id, version)
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartApi->api_vversion_cart_by_cart_id_delete: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**String**](.md)| Id reference to delete all items and cart | 
 **version** | **String**|  | 

### Return type

nil (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined



# **api_vversion_cart_by_cart_id_get**
> CartDto api_vversion_cart_by_cart_id_get(cart_id, version)

Gets a cart for a given Cart Id reference.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CartApi.new

cart_id = "cart_id_example" # String | string. Unique identifier of a cart

version = "version_example" # String | 


begin
  #Gets a cart for a given Cart Id reference.
  result = api_instance.api_vversion_cart_by_cart_id_get(cart_id, version)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartApi->api_vversion_cart_by_cart_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**String**](.md)| string. Unique identifier of a cart | 
 **version** | **String**|  | 

### Return type

[**CartDto**](CartDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0



# **api_vversion_cart_put**
> CartProductDto api_vversion_cart_put(version, opts)

Adds an item to a cart. A new cart is created if cartId is not specified on the item

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::CartApi.new

version = "version_example" # String | 

opts = { 
  cart_id: "cart_id_example", # String | Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty = 00000000-0000-0000-0000-000000000000)
  country_id: 56, # Integer | Country the cart item relates to
  product_id: 56, # Integer | Cart item (product) to add/update
  qty: 56 # Integer | the quantity to add/update for a given cart item (product)
}

begin
  #Adds an item to a cart. A new cart is created if cartId is not specified on the item
  result = api_instance.api_vversion_cart_put(version, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling CartApi->api_vversion_cart_put: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **String**|  | 
 **cart_id** | [**String**](.md)| Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty &#x3D; 00000000-0000-0000-0000-000000000000) | [optional] 
 **country_id** | **Integer**| Country the cart item relates to | [optional] 
 **product_id** | **Integer**| Cart item (product) to add/update | [optional] 
 **qty** | **Integer**| the quantity to add/update for a given cart item (product) | [optional] 

### Return type

[**CartProductDto**](CartProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0



