# SwaggerClient::CartDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cart_id** | **String** |  | [optional] 
**country_id** | **Integer** |  | [optional] 
**country_iso_code** | **String** |  | [optional] 
**items** | [**Array&lt;CartProductDto&gt;**](CartProductDto.md) |  | [optional] 
**total_net_price** | **Float** |  | [optional] 
**total_net_price_formatted** | **String** |  | [optional] 
**total_tax** | **Float** |  | [optional] 
**total_tax_formatted** | **String** |  | [optional] 
**total_gross_price** | **Float** |  | [optional] 
**total_gross_price_formatted** | **String** |  | [optional] 


