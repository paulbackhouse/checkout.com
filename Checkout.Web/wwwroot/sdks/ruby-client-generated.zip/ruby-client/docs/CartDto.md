# SwaggerClient::CartDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cart_id** | **String** | An Id of an exiting cart | [optional] 
**country_id** | **Integer** | The country Id this cart relates to | [optional] 
**country_iso_code** | **String** | The country ISO code the cart is valid for | [optional] 
**items** | [**Array&lt;CartProductDto&gt;**](CartProductDto.md) |  | [optional] 
**total_net_price** | **Float** |  | [optional] 
**total_net_price_formatted** | **String** |  | [optional] 
**total_tax** | **Float** |  | [optional] 
**total_tax_formatted** | **String** |  | [optional] 
**total_gross_price** | **Float** |  | [optional] 
**total_gross_price_formatted** | **String** |  | [optional] 


