# SwaggerClient::CountryDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**iso_code** | **String** |  | 
**currency_symbol** | **String** |  | [optional] 
**currency** | **String** |  | [optional] 
**tax** | **Float** |  | [optional] 
**tax_formatted** | **String** |  | [optional] 
**is_default** | **BOOLEAN** |  | [optional] 
**is_active** | **BOOLEAN** |  | [optional] 
**id** | **Integer** |  | [optional] 


