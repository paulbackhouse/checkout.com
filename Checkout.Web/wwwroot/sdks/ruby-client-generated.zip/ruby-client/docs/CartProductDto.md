# SwaggerClient::CartProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product_name** | **String** |  | [optional] 
**product_code** | **String** |  | [optional] 
**country_iso_code** | **String** |  | [optional] 
**net_price** | **Float** |  | [optional] 
**total_net_price** | **Float** |  | [optional] 
**total_net_price_formatted** | **String** |  | [optional] 
**tax_amount** | **Float** |  | [optional] 
**tax_amount_formatted** | **String** |  | [optional] 
**total_tax** | **Float** |  | [optional] 
**total_tax_formatted** | **String** |  | [optional] 
**total_gross_price** | **Float** |  | [optional] 
**total_gross_price_formatted** | **String** |  | [optional] 
**cart_id** | **String** | Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty &#x3D; 00000000-0000-0000-0000-000000000000) | [optional] 
**country_id** | **Integer** | Country the cart item relates to | [optional] 
**product_id** | **Integer** | Cart item (product) to add/update | [optional] 
**qty** | **Integer** | the quantity to add/update for a given cart item (product) | [optional] 


