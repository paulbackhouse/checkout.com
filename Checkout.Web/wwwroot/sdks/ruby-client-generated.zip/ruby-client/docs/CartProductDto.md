# SwaggerClient::CartProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**country_iso_code** | **String** |  | [optional] 
**net_price** | **Float** |  | [optional] 
**total_net_price** | **Float** |  | [optional] 
**total_net_price_formatted** | **String** |  | [optional] 
**tax_amount** | **Float** |  | [optional] 
**tax_amount_formatted** | **String** |  | [optional] 
**total_tax** | **Float** |  | [optional] 
**total_tax_formatted** | **String** |  | [optional] 
**total_gross_price** | **Float** |  | [optional] 
**total_gross_price_formatted** | **String** |  | [optional] 
**cart_id** | **String** |  | [optional] 
**country_id** | **Integer** |  | [optional] 
**product_id** | **Integer** |  | [optional] 
**qty** | **Integer** |  | [optional] 


