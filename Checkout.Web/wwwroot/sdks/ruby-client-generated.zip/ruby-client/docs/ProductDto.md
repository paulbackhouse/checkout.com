# SwaggerClient::ProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  | 
**short_description** | **String** |  | 
**net_price** | **Float** |  | [optional] 
**net_price_formatted** | **String** |  | [optional] 
**country** | [**CountryDto**](CountryDto.md) |  | 
**tax_amount** | **Float** |  | [optional] 
**tax_amount_formatted** | **String** |  | [optional] 
**id** | **Integer** |  | [optional] 
**name** | **String** |  | [optional] 


