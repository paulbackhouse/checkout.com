# SwaggerClient::ProductsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_vversion_products_by_product_id_get**](ProductsApi.md#api_vversion_products_by_product_id_get) | **GET** /api/v{version}/Products/{productId} | Gets a product by a given productId
[**api_vversion_products_get**](ProductsApi.md#api_vversion_products_get) | **GET** /api/v{version}/Products | Gets a collection of products available for a given countryId


# **api_vversion_products_by_product_id_get**
> ProductDto api_vversion_products_by_product_id_get(product_id, version)

Gets a product by a given productId

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::ProductsApi.new

product_id = 56 # Integer | Id to query for

version = "version_example" # String | 


begin
  #Gets a product by a given productId
  result = api_instance.api_vversion_products_by_product_id_get(product_id, version)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductsApi->api_vversion_products_by_product_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_id** | **Integer**| Id to query for | 
 **version** | **String**|  | 

### Return type

[**ProductDto**](ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0



# **api_vversion_products_get**
> PagedResultDtoProductDto api_vversion_products_get(version, opts)

Gets a collection of products available for a given countryId

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::ProductsApi.new

version = "version_example" # String | 

opts = { 
  country_id: 56, # Integer | Required. A countryId to request products for
  page_index: 56, # Integer | Zero based index querystring parameter requesting page. i.e first page = 0
  page_size: 56 # Integer | Page size querystring parameter required
}

begin
  #Gets a collection of products available for a given countryId
  result = api_instance.api_vversion_products_get(version, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductsApi->api_vversion_products_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **String**|  | 
 **country_id** | **Integer**| Required. A countryId to request products for | [optional] 
 **page_index** | **Integer**| Zero based index querystring parameter requesting page. i.e first page &#x3D; 0 | [optional] 
 **page_size** | **Integer**| Page size querystring parameter required | [optional] 

### Return type

[**PagedResultDtoProductDto**](PagedResultDtoProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0



