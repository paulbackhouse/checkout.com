# SwaggerClient::ProductsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_vversion_products_by_country_id_get**](ProductsApi.md#api_vversion_products_by_country_id_get) | **GET** /api/v{version}/Products/{countryId} | 
[**api_vversion_products_by_product_id_get**](ProductsApi.md#api_vversion_products_by_product_id_get) | **GET** /api/v{version}/Products/{productId} | 


# **api_vversion_products_by_country_id_get**
> Array&lt;ProductDto&gt; api_vversion_products_by_country_id_get(country_id, version, opts)



### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::ProductsApi.new

country_id = 56 # Integer | 

version = "version_example" # String | 

opts = { 
  page_index: 56, # Integer | 
  page_size: 56 # Integer | 
}

begin
  result = api_instance.api_vversion_products_by_country_id_get(country_id, version, opts)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductsApi->api_vversion_products_by_country_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **country_id** | **Integer**|  | 
 **version** | **String**|  | 
 **page_index** | **Integer**|  | [optional] 
 **page_size** | **Integer**|  | [optional] 

### Return type

[**Array&lt;ProductDto&gt;**](ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0



# **api_vversion_products_by_product_id_get**
> ProductDto api_vversion_products_by_product_id_get(product_id, version)



### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::ProductsApi.new

product_id = 56 # Integer | 

version = "version_example" # String | 


begin
  result = api_instance.api_vversion_products_by_product_id_get(product_id, version)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling ProductsApi->api_vversion_products_by_product_id_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_id** | **Integer**|  | 
 **version** | **String**|  | 

### Return type

[**ProductDto**](ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0



