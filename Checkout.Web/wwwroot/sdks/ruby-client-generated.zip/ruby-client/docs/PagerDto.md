# SwaggerClient::PagerDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **Integer** |  | [optional] 
**page_number** | **Integer** |  | [optional] 
**page_count** | **Integer** |  | [optional] 
**page_index** | **Integer** |  | [optional] 
**page_size** | **Integer** |  | [optional] 
**is_last_page** | **BOOLEAN** |  | [optional] 
**is_first_page** | **BOOLEAN** |  | [optional] 


