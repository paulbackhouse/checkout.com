# CheckoutcomCartApi.CartProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productName** | **String** |  | [optional] 
**productCode** | **String** |  | [optional] 
**countryIsoCode** | **String** |  | [optional] 
**netPrice** | **Number** |  | [optional] 
**totalNetPrice** | **Number** |  | [optional] 
**totalNetPriceFormatted** | **String** |  | [optional] 
**taxAmount** | **Number** |  | [optional] 
**taxAmountFormatted** | **String** |  | [optional] 
**totalTax** | **Number** |  | [optional] 
**totalTaxFormatted** | **String** |  | [optional] 
**totalGrossPrice** | **Number** |  | [optional] 
**totalGrossPriceFormatted** | **String** |  | [optional] 
**cartId** | **String** | Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty &#x3D; 00000000-0000-0000-0000-000000000000) | [optional] 
**countryId** | **Number** | Country the cart item relates to | [optional] 
**productId** | **Number** | Cart item (product) to add/update | [optional] 
**qty** | **Number** | the quantity to add/update for a given cart item (product) | [optional] 


