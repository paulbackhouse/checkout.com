# CheckoutcomCartApi.CartProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**countryIsoCode** | **String** |  | [optional] 
**netPrice** | **Number** |  | [optional] 
**totalNetPrice** | **Number** |  | [optional] 
**totalNetPriceFormatted** | **String** |  | [optional] 
**taxAmount** | **Number** |  | [optional] 
**taxAmountFormatted** | **String** |  | [optional] 
**totalTax** | **Number** |  | [optional] 
**totalTaxFormatted** | **String** |  | [optional] 
**totalGrossPrice** | **Number** |  | [optional] 
**totalGrossPriceFormatted** | **String** |  | [optional] 
**cartId** | **String** |  | [optional] 
**countryId** | **Number** |  | [optional] 
**productId** | **Number** |  | [optional] 
**qty** | **Number** |  | [optional] 


