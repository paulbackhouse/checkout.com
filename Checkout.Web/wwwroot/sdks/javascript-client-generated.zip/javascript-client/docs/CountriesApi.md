# CheckoutcomCartApi.CountriesApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionCountriesByCountryIdGet**](CountriesApi.md#apiVversionCountriesByCountryIdGet) | **GET** /api/v{version}/Countries/{countryId} | Gets a country by a given countryId
[**apiVversionCountriesGet**](CountriesApi.md#apiVversionCountriesGet) | **GET** /api/v{version}/Countries | Gets a collection of countries available for order process


<a name="apiVversionCountriesByCountryIdGet"></a>
# **apiVversionCountriesByCountryIdGet**
> CountryDto apiVversionCountriesByCountryIdGet(countryId, version)

Gets a country by a given countryId

### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.CountriesApi();

var countryId = 56; // Number | A given country Id to search for

var version = "version_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.apiVversionCountriesByCountryIdGet(countryId, version, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **countryId** | **Number**| A given country Id to search for | 
 **version** | **String**|  | 

### Return type

[**CountryDto**](CountryDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

<a name="apiVversionCountriesGet"></a>
# **apiVversionCountriesGet**
> [CountryDto] apiVversionCountriesGet(version)

Gets a collection of countries available for order process

### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.CountriesApi();

var version = "version_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.apiVversionCountriesGet(version, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **String**|  | 

### Return type

[**[CountryDto]**](CountryDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

