# CheckoutcomCartApi.ProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  | 
**shortDescription** | **String** |  | 
**netPrice** | **Number** |  | [optional] 
**netPriceFormatted** | **String** |  | [optional] 
**country** | [**CountryDto**](CountryDto.md) |  | 
**taxAmount** | **Number** |  | [optional] 
**taxAmountFormatted** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 


