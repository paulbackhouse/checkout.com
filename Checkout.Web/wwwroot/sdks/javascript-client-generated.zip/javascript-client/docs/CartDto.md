# CheckoutcomCartApi.CartDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cartId** | **String** | An Id of an exiting cart | [optional] 
**countryId** | **Number** | The country Id this cart relates to | [optional] 
**countryIsoCode** | **String** | The country ISO code the cart is valid for | [optional] 
**items** | [**[CartProductDto]**](CartProductDto.md) |  | [optional] 
**totalNetPrice** | **Number** |  | [optional] 
**totalNetPriceFormatted** | **String** |  | [optional] 
**totalTax** | **Number** |  | [optional] 
**totalTaxFormatted** | **String** |  | [optional] 
**totalGrossPrice** | **Number** |  | [optional] 
**totalGrossPriceFormatted** | **String** |  | [optional] 


