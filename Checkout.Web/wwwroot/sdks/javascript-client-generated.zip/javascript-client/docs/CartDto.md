# CheckoutcomCartApi.CartDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cartId** | **String** |  | [optional] 
**countryId** | **Number** |  | [optional] 
**countryIsoCode** | **String** |  | [optional] 
**items** | [**[CartProductDto]**](CartProductDto.md) |  | [optional] 
**totalNetPrice** | **Number** |  | [optional] 
**totalNetPriceFormatted** | **String** |  | [optional] 
**totalTax** | **Number** |  | [optional] 
**totalTaxFormatted** | **String** |  | [optional] 
**totalGrossPrice** | **Number** |  | [optional] 
**totalGrossPriceFormatted** | **String** |  | [optional] 


