# CheckoutcomCartApi.ProductsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionProductsByProductIdGet**](ProductsApi.md#apiVversionProductsByProductIdGet) | **GET** /api/v{version}/Products/{productId} | Gets a product by a given productId
[**apiVversionProductsGet**](ProductsApi.md#apiVversionProductsGet) | **GET** /api/v{version}/Products | Gets a collection of products available for a given countryId


<a name="apiVversionProductsByProductIdGet"></a>
# **apiVversionProductsByProductIdGet**
> ProductDto apiVversionProductsByProductIdGet(productId, version)

Gets a product by a given productId

### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.ProductsApi();

var productId = 56; // Number | Id to query for

var version = "version_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.apiVversionProductsByProductIdGet(productId, version, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productId** | **Number**| Id to query for | 
 **version** | **String**|  | 

### Return type

[**ProductDto**](ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

<a name="apiVversionProductsGet"></a>
# **apiVversionProductsGet**
> PagedResultDtoProductDto apiVversionProductsGet(version, opts)

Gets a collection of products available for a given countryId

### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.ProductsApi();

var version = "version_example"; // String | 

var opts = { 
  'countryId': 56, // Number | Required. A countryId to request products for
  'pageIndex': 56, // Number | Zero based index querystring parameter requesting page. i.e first page = 0
  'pageSize': 56 // Number | Page size querystring parameter required
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.apiVversionProductsGet(version, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **String**|  | 
 **countryId** | **Number**| Required. A countryId to request products for | [optional] 
 **pageIndex** | **Number**| Zero based index querystring parameter requesting page. i.e first page &#x3D; 0 | [optional] 
 **pageSize** | **Number**| Page size querystring parameter required | [optional] 

### Return type

[**PagedResultDtoProductDto**](PagedResultDtoProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

