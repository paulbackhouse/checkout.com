# CheckoutcomCartApi.ProductsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionProductsByCountryIdGet**](ProductsApi.md#apiVversionProductsByCountryIdGet) | **GET** /api/v{version}/Products/{countryId} | 
[**apiVversionProductsByProductIdGet**](ProductsApi.md#apiVversionProductsByProductIdGet) | **GET** /api/v{version}/Products/{productId} | 


<a name="apiVversionProductsByCountryIdGet"></a>
# **apiVversionProductsByCountryIdGet**
> [ProductDto] apiVversionProductsByCountryIdGet(countryId, version, opts)



### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.ProductsApi();

var countryId = 56; // Number | 

var version = "version_example"; // String | 

var opts = { 
  'pageIndex': 56, // Number | 
  'pageSize': 56 // Number | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.apiVversionProductsByCountryIdGet(countryId, version, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **countryId** | **Number**|  | 
 **version** | **String**|  | 
 **pageIndex** | **Number**|  | [optional] 
 **pageSize** | **Number**|  | [optional] 

### Return type

[**[ProductDto]**](ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

<a name="apiVversionProductsByProductIdGet"></a>
# **apiVversionProductsByProductIdGet**
> ProductDto apiVversionProductsByProductIdGet(productId, version)



### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.ProductsApi();

var productId = 56; // Number | 

var version = "version_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.apiVversionProductsByProductIdGet(productId, version, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **productId** | **Number**|  | 
 **version** | **String**|  | 

### Return type

[**ProductDto**](ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

