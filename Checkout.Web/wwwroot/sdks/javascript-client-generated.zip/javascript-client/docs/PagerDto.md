# CheckoutcomCartApi.PagerDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **Number** |  | [optional] 
**pageNumber** | **Number** |  | [optional] 
**pageCount** | **Number** |  | [optional] 
**pageIndex** | **Number** |  | [optional] 
**pageSize** | **Number** |  | [optional] 
**isLastPage** | **Boolean** |  | [optional] 
**isFirstPage** | **Boolean** |  | [optional] 


