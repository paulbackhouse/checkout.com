# CheckoutcomCartApi.CartApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionCartByCartIdByProductIdDelete**](CartApi.md#apiVversionCartByCartIdByProductIdDelete) | **DELETE** /api/v{version}/Cart/{cartId}/{productId} | Removes a cart item for a given cartId and productId
[**apiVversionCartByCartIdDelete**](CartApi.md#apiVversionCartByCartIdDelete) | **DELETE** /api/v{version}/Cart/{cartId} | Removes and instance of a cart object and associated items
[**apiVversionCartByCartIdGet**](CartApi.md#apiVversionCartByCartIdGet) | **GET** /api/v{version}/Cart/{cartId} | Gets a cart for a given Cart Id reference.
[**apiVversionCartPut**](CartApi.md#apiVversionCartPut) | **PUT** /api/v{version}/Cart | Adds an item to a cart. A new cart is created if cartId is not specified on the item


<a name="apiVversionCartByCartIdByProductIdDelete"></a>
# **apiVversionCartByCartIdByProductIdDelete**
> apiVversionCartByCartIdByProductIdDelete(cartId, productId, version)

Removes a cart item for a given cartId and productId

### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.CartApi();

var cartId = "cartId_example"; // String | CartId reference to delete a product against

var productId = 56; // Number | ProductId reference to delete from a given cartId reference

var version = "version_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.apiVversionCartByCartIdByProductIdDelete(cartId, productId, version, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartId** | [**String**](.md)| CartId reference to delete a product against | 
 **productId** | **Number**| ProductId reference to delete from a given cartId reference | 
 **version** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="apiVversionCartByCartIdDelete"></a>
# **apiVversionCartByCartIdDelete**
> apiVversionCartByCartIdDelete(cartId, version)

Removes and instance of a cart object and associated items

### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.CartApi();

var cartId = "cartId_example"; // String | Id reference to delete all items and cart

var version = "version_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.apiVversionCartByCartIdDelete(cartId, version, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartId** | [**String**](.md)| Id reference to delete all items and cart | 
 **version** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="apiVversionCartByCartIdGet"></a>
# **apiVversionCartByCartIdGet**
> CartDto apiVversionCartByCartIdGet(cartId, version)

Gets a cart for a given Cart Id reference.

### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.CartApi();

var cartId = "cartId_example"; // String | string. Unique identifier of a cart

var version = "version_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.apiVversionCartByCartIdGet(cartId, version, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartId** | [**String**](.md)| string. Unique identifier of a cart | 
 **version** | **String**|  | 

### Return type

[**CartDto**](CartDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

<a name="apiVversionCartPut"></a>
# **apiVversionCartPut**
> CartProductDto apiVversionCartPut(version, opts)

Adds an item to a cart. A new cart is created if cartId is not specified on the item

### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.CartApi();

var version = "version_example"; // String | 

var opts = { 
  'cartId': "cartId_example", // String | Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty = 00000000-0000-0000-0000-000000000000)
  'countryId': 56, // Number | Country the cart item relates to
  'productId': 56, // Number | Cart item (product) to add/update
  'qty': 56 // Number | the quantity to add/update for a given cart item (product)
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.apiVversionCartPut(version, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **String**|  | 
 **cartId** | [**String**](.md)| Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty &#x3D; 00000000-0000-0000-0000-000000000000) | [optional] 
 **countryId** | **Number**| Country the cart item relates to | [optional] 
 **productId** | **Number**| Cart item (product) to add/update | [optional] 
 **qty** | **Number**| the quantity to add/update for a given cart item (product) | [optional] 

### Return type

[**CartProductDto**](CartProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

