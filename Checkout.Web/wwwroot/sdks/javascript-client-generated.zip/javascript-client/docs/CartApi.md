# CheckoutcomCartApi.CartApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionCartByCartIdByProductIdDelete**](CartApi.md#apiVversionCartByCartIdByProductIdDelete) | **DELETE** /api/v{version}/Cart/{cartId}/{productId} | 
[**apiVversionCartByCartIdDelete**](CartApi.md#apiVversionCartByCartIdDelete) | **DELETE** /api/v{version}/Cart/{cartId} | 
[**apiVversionCartByCartIdGet**](CartApi.md#apiVversionCartByCartIdGet) | **GET** /api/v{version}/Cart/{cartId} | 
[**apiVversionCartPut**](CartApi.md#apiVversionCartPut) | **PUT** /api/v{version}/Cart | 


<a name="apiVversionCartByCartIdByProductIdDelete"></a>
# **apiVversionCartByCartIdByProductIdDelete**
> apiVversionCartByCartIdByProductIdDelete(cartId, productId, version)



### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.CartApi();

var cartId = "cartId_example"; // String | 

var productId = 56; // Number | 

var version = "version_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.apiVversionCartByCartIdByProductIdDelete(cartId, productId, version, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartId** | [**String**](.md)|  | 
 **productId** | **Number**|  | 
 **version** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="apiVversionCartByCartIdDelete"></a>
# **apiVversionCartByCartIdDelete**
> apiVversionCartByCartIdDelete(cartId, version)



### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.CartApi();

var cartId = "cartId_example"; // String | 

var version = "version_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.apiVversionCartByCartIdDelete(cartId, version, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartId** | [**String**](.md)|  | 
 **version** | **String**|  | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="apiVversionCartByCartIdGet"></a>
# **apiVversionCartByCartIdGet**
> CartDto apiVversionCartByCartIdGet(cartId, version)



### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.CartApi();

var cartId = "cartId_example"; // String | 

var version = "version_example"; // String | 


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.apiVversionCartByCartIdGet(cartId, version, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cartId** | [**String**](.md)|  | 
 **version** | **String**|  | 

### Return type

[**CartDto**](CartDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

<a name="apiVversionCartPut"></a>
# **apiVversionCartPut**
> CartProductDto apiVversionCartPut(version, opts)



### Example
```javascript
var CheckoutcomCartApi = require('checkoutcom_cart_api');

var apiInstance = new CheckoutcomCartApi.CartApi();

var version = "version_example"; // String | 

var opts = { 
  'cartId': "cartId_example", // String | 
  'countryId': 56, // Number | 
  'productId': 56, // Number | 
  'qty': 56 // Number | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.apiVversionCartPut(version, opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **String**|  | 
 **cartId** | [**String**](.md)|  | [optional] 
 **countryId** | **Number**|  | [optional] 
 **productId** | **Number**|  | [optional] 
 **qty** | **Number**|  | [optional] 

### Return type

[**CartProductDto**](CartProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

