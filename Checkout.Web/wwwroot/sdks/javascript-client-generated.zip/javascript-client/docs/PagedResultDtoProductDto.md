# CheckoutcomCartApi.PagedResultDtoProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**[ProductDto]**](ProductDto.md) |  | [optional] 
**pager** | [**PagerDto**](PagerDto.md) |  | [optional] 


