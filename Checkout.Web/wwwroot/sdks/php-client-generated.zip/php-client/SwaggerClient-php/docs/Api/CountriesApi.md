# Swagger\Client\CountriesApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionCountriesByCountryIdGet**](CountriesApi.md#apiVversionCountriesByCountryIdGet) | **GET** /api/v{version}/Countries/{countryId} | Gets a country by a given countryId
[**apiVversionCountriesGet**](CountriesApi.md#apiVversionCountriesGet) | **GET** /api/v{version}/Countries | Gets a collection of countries available for order process


# **apiVversionCountriesByCountryIdGet**
> \Swagger\Client\Model\CountryDto apiVversionCountriesByCountryIdGet($country_id, $version)

Gets a country by a given countryId

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CountriesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$country_id = 56; // int | A given country Id to search for
$version = "version_example"; // string | 

try {
    $result = $apiInstance->apiVversionCountriesByCountryIdGet($country_id, $version);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CountriesApi->apiVversionCountriesByCountryIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **country_id** | **int**| A given country Id to search for |
 **version** | **string**|  |

### Return type

[**\Swagger\Client\Model\CountryDto**](../Model/CountryDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **apiVversionCountriesGet**
> \Swagger\Client\Model\CountryDto[] apiVversionCountriesGet($version)

Gets a collection of countries available for order process

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CountriesApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$version = "version_example"; // string | 

try {
    $result = $apiInstance->apiVversionCountriesGet($version);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CountriesApi->apiVversionCountriesGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **string**|  |

### Return type

[**\Swagger\Client\Model\CountryDto[]**](../Model/CountryDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

