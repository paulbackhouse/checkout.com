# Swagger\Client\CartApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionCartByCartIdByProductIdDelete**](CartApi.md#apiVversionCartByCartIdByProductIdDelete) | **DELETE** /api/v{version}/Cart/{cartId}/{productId} | 
[**apiVversionCartByCartIdDelete**](CartApi.md#apiVversionCartByCartIdDelete) | **DELETE** /api/v{version}/Cart/{cartId} | 
[**apiVversionCartByCartIdGet**](CartApi.md#apiVversionCartByCartIdGet) | **GET** /api/v{version}/Cart/{cartId} | 
[**apiVversionCartPut**](CartApi.md#apiVversionCartPut) | **PUT** /api/v{version}/Cart | 


# **apiVversionCartByCartIdByProductIdDelete**
> apiVversionCartByCartIdByProductIdDelete($cart_id, $product_id, $version)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CartApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$cart_id = "cart_id_example"; // string | 
$product_id = 56; // int | 
$version = "version_example"; // string | 

try {
    $apiInstance->apiVversionCartByCartIdByProductIdDelete($cart_id, $product_id, $version);
} catch (Exception $e) {
    echo 'Exception when calling CartApi->apiVversionCartByCartIdByProductIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**string**](../Model/.md)|  |
 **product_id** | **int**|  |
 **version** | **string**|  |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **apiVversionCartByCartIdDelete**
> apiVversionCartByCartIdDelete($cart_id, $version)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CartApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$cart_id = "cart_id_example"; // string | 
$version = "version_example"; // string | 

try {
    $apiInstance->apiVversionCartByCartIdDelete($cart_id, $version);
} catch (Exception $e) {
    echo 'Exception when calling CartApi->apiVversionCartByCartIdDelete: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**string**](../Model/.md)|  |
 **version** | **string**|  |

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **apiVversionCartByCartIdGet**
> \Swagger\Client\Model\CartDto apiVversionCartByCartIdGet($cart_id, $version)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CartApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$cart_id = "cart_id_example"; // string | 
$version = "version_example"; // string | 

try {
    $result = $apiInstance->apiVversionCartByCartIdGet($cart_id, $version);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CartApi->apiVversionCartByCartIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**string**](../Model/.md)|  |
 **version** | **string**|  |

### Return type

[**\Swagger\Client\Model\CartDto**](../Model/CartDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **apiVversionCartPut**
> \Swagger\Client\Model\CartProductDto apiVversionCartPut($version, $cart_id, $country_id, $product_id, $qty)



### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CartApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$version = "version_example"; // string | 
$cart_id = "cart_id_example"; // string | 
$country_id = 56; // int | 
$product_id = 56; // int | 
$qty = 56; // int | 

try {
    $result = $apiInstance->apiVversionCartPut($version, $cart_id, $country_id, $product_id, $qty);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CartApi->apiVversionCartPut: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **string**|  |
 **cart_id** | [**string**](../Model/.md)|  | [optional]
 **country_id** | **int**|  | [optional]
 **product_id** | **int**|  | [optional]
 **qty** | **int**|  | [optional]

### Return type

[**\Swagger\Client\Model\CartProductDto**](../Model/CartProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

