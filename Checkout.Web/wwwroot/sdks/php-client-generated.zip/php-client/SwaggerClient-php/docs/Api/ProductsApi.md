# Swagger\Client\ProductsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiVversionProductsByProductIdGet**](ProductsApi.md#apiVversionProductsByProductIdGet) | **GET** /api/v{version}/Products/{productId} | Gets a product by a given productId
[**apiVversionProductsGet**](ProductsApi.md#apiVversionProductsGet) | **GET** /api/v{version}/Products | Gets a collection of products available for a given countryId


# **apiVversionProductsByProductIdGet**
> \Swagger\Client\Model\ProductDto apiVversionProductsByProductIdGet($product_id, $version)

Gets a product by a given productId

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProductsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$product_id = 56; // int | Id to query for
$version = "version_example"; // string | 

try {
    $result = $apiInstance->apiVversionProductsByProductIdGet($product_id, $version);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductsApi->apiVversionProductsByProductIdGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_id** | **int**| Id to query for |
 **version** | **string**|  |

### Return type

[**\Swagger\Client\Model\ProductDto**](../Model/ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **apiVversionProductsGet**
> \Swagger\Client\Model\PagedResultDtoProductDto apiVversionProductsGet($version, $country_id, $page_index, $page_size)

Gets a collection of products available for a given countryId

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\ProductsApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$version = "version_example"; // string | 
$country_id = 56; // int | Required. A countryId to request products for
$page_index = 56; // int | Zero based index querystring parameter requesting page. i.e first page = 0
$page_size = 56; // int | Page size querystring parameter required

try {
    $result = $apiInstance->apiVversionProductsGet($version, $country_id, $page_index, $page_size);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ProductsApi->apiVversionProductsGet: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **string**|  |
 **country_id** | **int**| Required. A countryId to request products for | [optional]
 **page_index** | **int**| Zero based index querystring parameter requesting page. i.e first page &#x3D; 0 | [optional]
 **page_size** | **int**| Page size querystring parameter required | [optional]

### Return type

[**\Swagger\Client\Model\PagedResultDtoProductDto**](../Model/PagedResultDtoProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

