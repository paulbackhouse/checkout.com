# PagedResultDtoProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**\Swagger\Client\Model\ProductDto[]**](ProductDto.md) |  | [optional] 
**pager** | [**\Swagger\Client\Model\PagerDto**](PagerDto.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


