# CartProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product_name** | **string** |  | [optional] 
**product_code** | **string** |  | [optional] 
**country_iso_code** | **string** |  | [optional] 
**net_price** | **double** |  | [optional] 
**total_net_price** | **double** |  | [optional] 
**total_net_price_formatted** | **string** |  | [optional] 
**tax_amount** | **double** |  | [optional] 
**tax_amount_formatted** | **string** |  | [optional] 
**total_tax** | **double** |  | [optional] 
**total_tax_formatted** | **string** |  | [optional] 
**total_gross_price** | **double** |  | [optional] 
**total_gross_price_formatted** | **string** |  | [optional] 
**cart_id** | **string** | Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty &#x3D; 00000000-0000-0000-0000-000000000000) | [optional] 
**country_id** | **int** | Country the cart item relates to | [optional] 
**product_id** | **int** | Cart item (product) to add/update | [optional] 
**qty** | **int** | the quantity to add/update for a given cart item (product) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


