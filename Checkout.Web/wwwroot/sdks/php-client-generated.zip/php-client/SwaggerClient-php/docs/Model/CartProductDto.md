# CartProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**country_iso_code** | **string** |  | [optional] 
**net_price** | **double** |  | [optional] 
**total_net_price** | **double** |  | [optional] 
**total_net_price_formatted** | **string** |  | [optional] 
**tax_amount** | **double** |  | [optional] 
**tax_amount_formatted** | **string** |  | [optional] 
**total_tax** | **double** |  | [optional] 
**total_tax_formatted** | **string** |  | [optional] 
**total_gross_price** | **double** |  | [optional] 
**total_gross_price_formatted** | **string** |  | [optional] 
**cart_id** | **string** |  | [optional] 
**country_id** | **int** |  | [optional] 
**product_id** | **int** |  | [optional] 
**qty** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


