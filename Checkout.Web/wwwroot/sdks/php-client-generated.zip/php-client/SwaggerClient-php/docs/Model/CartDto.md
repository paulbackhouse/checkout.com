# CartDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cart_id** | **string** |  | [optional] 
**country_id** | **int** |  | [optional] 
**country_iso_code** | **string** |  | [optional] 
**items** | [**\Swagger\Client\Model\CartProductDto[]**](CartProductDto.md) |  | [optional] 
**total_net_price** | **double** |  | [optional] 
**total_net_price_formatted** | **string** |  | [optional] 
**total_tax** | **double** |  | [optional] 
**total_tax_formatted** | **string** |  | [optional] 
**total_gross_price** | **double** |  | [optional] 
**total_gross_price_formatted** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


