# CartDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cart_id** | **string** | An Id of an exiting cart | [optional] 
**country_id** | **int** | The country Id this cart relates to | [optional] 
**country_iso_code** | **string** | The country ISO code the cart is valid for | [optional] 
**items** | [**\Swagger\Client\Model\CartProductDto[]**](CartProductDto.md) |  | [optional] 
**total_net_price** | **double** |  | [optional] 
**total_net_price_formatted** | **string** |  | [optional] 
**total_tax** | **double** |  | [optional] 
**total_tax_formatted** | **string** |  | [optional] 
**total_gross_price** | **double** |  | [optional] 
**total_gross_price_formatted** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


