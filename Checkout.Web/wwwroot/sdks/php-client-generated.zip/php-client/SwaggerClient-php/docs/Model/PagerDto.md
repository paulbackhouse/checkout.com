# PagerDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **int** |  | [optional] 
**page_number** | **int** |  | [optional] 
**page_count** | **int** |  | [optional] 
**page_index** | **int** |  | [optional] 
**page_size** | **int** |  | [optional] 
**is_last_page** | **bool** |  | [optional] 
**is_first_page** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


