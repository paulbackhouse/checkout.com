# ProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **string** |  | 
**short_description** | **string** |  | 
**net_price** | **double** |  | [optional] 
**net_price_formatted** | **string** |  | [optional] 
**country** | [**\Swagger\Client\Model\CountryDto**](CountryDto.md) |  | 
**tax_amount** | **double** |  | [optional] 
**tax_amount_formatted** | **string** |  | [optional] 
**id** | **int** |  | [optional] 
**name** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


