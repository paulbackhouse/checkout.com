# CountryDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** |  | 
**iso_code** | **string** |  | 
**currency_symbol** | **string** |  | [optional] 
**currency** | **string** |  | [optional] 
**tax** | **double** |  | [optional] 
**tax_formatted** | **string** |  | [optional] 
**is_default** | **bool** |  | [optional] 
**is_active** | **bool** |  | [optional] 
**id** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


