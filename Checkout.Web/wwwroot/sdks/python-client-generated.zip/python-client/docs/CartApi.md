# swagger_client.CartApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_vversion_cart_by_cart_id_by_product_id_delete**](CartApi.md#api_vversion_cart_by_cart_id_by_product_id_delete) | **DELETE** /api/v{version}/Cart/{cartId}/{productId} | Removes a cart item for a given cartId and productId
[**api_vversion_cart_by_cart_id_delete**](CartApi.md#api_vversion_cart_by_cart_id_delete) | **DELETE** /api/v{version}/Cart/{cartId} | Removes and instance of a cart object and associated items
[**api_vversion_cart_by_cart_id_get**](CartApi.md#api_vversion_cart_by_cart_id_get) | **GET** /api/v{version}/Cart/{cartId} | Gets a cart for a given Cart Id reference.
[**api_vversion_cart_put**](CartApi.md#api_vversion_cart_put) | **PUT** /api/v{version}/Cart | Adds an item to a cart. A new cart is created if cartId is not specified on the item


# **api_vversion_cart_by_cart_id_by_product_id_delete**
> api_vversion_cart_by_cart_id_by_product_id_delete(cart_id, product_id, version)

Removes a cart item for a given cartId and productId

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CartApi()
cart_id = 'cart_id_example' # str | CartId reference to delete a product against
product_id = 56 # int | ProductId reference to delete from a given cartId reference
version = 'version_example' # str | 

try:
    # Removes a cart item for a given cartId and productId
    api_instance.api_vversion_cart_by_cart_id_by_product_id_delete(cart_id, product_id, version)
except ApiException as e:
    print("Exception when calling CartApi->api_vversion_cart_by_cart_id_by_product_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**str**](.md)| CartId reference to delete a product against | 
 **product_id** | **int**| ProductId reference to delete from a given cartId reference | 
 **version** | **str**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_vversion_cart_by_cart_id_delete**
> api_vversion_cart_by_cart_id_delete(cart_id, version)

Removes and instance of a cart object and associated items

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CartApi()
cart_id = 'cart_id_example' # str | Id reference to delete all items and cart
version = 'version_example' # str | 

try:
    # Removes and instance of a cart object and associated items
    api_instance.api_vversion_cart_by_cart_id_delete(cart_id, version)
except ApiException as e:
    print("Exception when calling CartApi->api_vversion_cart_by_cart_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**str**](.md)| Id reference to delete all items and cart | 
 **version** | **str**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_vversion_cart_by_cart_id_get**
> CartDto api_vversion_cart_by_cart_id_get(cart_id, version)

Gets a cart for a given Cart Id reference.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CartApi()
cart_id = 'cart_id_example' # str | string. Unique identifier of a cart
version = 'version_example' # str | 

try:
    # Gets a cart for a given Cart Id reference.
    api_response = api_instance.api_vversion_cart_by_cart_id_get(cart_id, version)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CartApi->api_vversion_cart_by_cart_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**str**](.md)| string. Unique identifier of a cart | 
 **version** | **str**|  | 

### Return type

[**CartDto**](CartDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_vversion_cart_put**
> CartProductDto api_vversion_cart_put(version, cart_id=cart_id, country_id=country_id, product_id=product_id, qty=qty)

Adds an item to a cart. A new cart is created if cartId is not specified on the item

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CartApi()
version = 'version_example' # str | 
cart_id = 'cart_id_example' # str | Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty = 00000000-0000-0000-0000-000000000000) (optional)
country_id = 56 # int | Country the cart item relates to (optional)
product_id = 56 # int | Cart item (product) to add/update (optional)
qty = 56 # int | the quantity to add/update for a given cart item (product) (optional)

try:
    # Adds an item to a cart. A new cart is created if cartId is not specified on the item
    api_response = api_instance.api_vversion_cart_put(version, cart_id=cart_id, country_id=country_id, product_id=product_id, qty=qty)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CartApi->api_vversion_cart_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **str**|  | 
 **cart_id** | [**str**](.md)| Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty &#x3D; 00000000-0000-0000-0000-000000000000) | [optional] 
 **country_id** | **int**| Country the cart item relates to | [optional] 
 **product_id** | **int**| Cart item (product) to add/update | [optional] 
 **qty** | **int**| the quantity to add/update for a given cart item (product) | [optional] 

### Return type

[**CartProductDto**](CartProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

