# swagger_client.CartApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_vversion_cart_by_cart_id_by_product_id_delete**](CartApi.md#api_vversion_cart_by_cart_id_by_product_id_delete) | **DELETE** /api/v{version}/Cart/{cartId}/{productId} | 
[**api_vversion_cart_by_cart_id_delete**](CartApi.md#api_vversion_cart_by_cart_id_delete) | **DELETE** /api/v{version}/Cart/{cartId} | 
[**api_vversion_cart_by_cart_id_get**](CartApi.md#api_vversion_cart_by_cart_id_get) | **GET** /api/v{version}/Cart/{cartId} | 
[**api_vversion_cart_put**](CartApi.md#api_vversion_cart_put) | **PUT** /api/v{version}/Cart | 


# **api_vversion_cart_by_cart_id_by_product_id_delete**
> api_vversion_cart_by_cart_id_by_product_id_delete(cart_id, product_id, version)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CartApi()
cart_id = 'cart_id_example' # str | 
product_id = 56 # int | 
version = 'version_example' # str | 

try:
    api_instance.api_vversion_cart_by_cart_id_by_product_id_delete(cart_id, product_id, version)
except ApiException as e:
    print("Exception when calling CartApi->api_vversion_cart_by_cart_id_by_product_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**str**](.md)|  | 
 **product_id** | **int**|  | 
 **version** | **str**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_vversion_cart_by_cart_id_delete**
> api_vversion_cart_by_cart_id_delete(cart_id, version)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CartApi()
cart_id = 'cart_id_example' # str | 
version = 'version_example' # str | 

try:
    api_instance.api_vversion_cart_by_cart_id_delete(cart_id, version)
except ApiException as e:
    print("Exception when calling CartApi->api_vversion_cart_by_cart_id_delete: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**str**](.md)|  | 
 **version** | **str**|  | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_vversion_cart_by_cart_id_get**
> CartDto api_vversion_cart_by_cart_id_get(cart_id, version)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CartApi()
cart_id = 'cart_id_example' # str | 
version = 'version_example' # str | 

try:
    api_response = api_instance.api_vversion_cart_by_cart_id_get(cart_id, version)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CartApi->api_vversion_cart_by_cart_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cart_id** | [**str**](.md)|  | 
 **version** | **str**|  | 

### Return type

[**CartDto**](CartDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_vversion_cart_put**
> CartProductDto api_vversion_cart_put(version, cart_id=cart_id, country_id=country_id, product_id=product_id, qty=qty)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CartApi()
version = 'version_example' # str | 
cart_id = 'cart_id_example' # str |  (optional)
country_id = 56 # int |  (optional)
product_id = 56 # int |  (optional)
qty = 56 # int |  (optional)

try:
    api_response = api_instance.api_vversion_cart_put(version, cart_id=cart_id, country_id=country_id, product_id=product_id, qty=qty)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CartApi->api_vversion_cart_put: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **str**|  | 
 **cart_id** | [**str**](.md)|  | [optional] 
 **country_id** | **int**|  | [optional] 
 **product_id** | **int**|  | [optional] 
 **qty** | **int**|  | [optional] 

### Return type

[**CartProductDto**](CartProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

