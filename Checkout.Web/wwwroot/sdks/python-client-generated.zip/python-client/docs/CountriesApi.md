# swagger_client.CountriesApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_vversion_countries_by_country_id_get**](CountriesApi.md#api_vversion_countries_by_country_id_get) | **GET** /api/v{version}/Countries/{countryId} | Gets a country by a given countryId
[**api_vversion_countries_get**](CountriesApi.md#api_vversion_countries_get) | **GET** /api/v{version}/Countries | Gets a collection of countries available for order process


# **api_vversion_countries_by_country_id_get**
> CountryDto api_vversion_countries_by_country_id_get(country_id, version)

Gets a country by a given countryId

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CountriesApi()
country_id = 56 # int | A given country Id to search for
version = 'version_example' # str | 

try:
    # Gets a country by a given countryId
    api_response = api_instance.api_vversion_countries_by_country_id_get(country_id, version)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CountriesApi->api_vversion_countries_by_country_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **country_id** | **int**| A given country Id to search for | 
 **version** | **str**|  | 

### Return type

[**CountryDto**](CountryDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_vversion_countries_get**
> list[CountryDto] api_vversion_countries_get(version)

Gets a collection of countries available for order process

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CountriesApi()
version = 'version_example' # str | 

try:
    # Gets a collection of countries available for order process
    api_response = api_instance.api_vversion_countries_get(version)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CountriesApi->api_vversion_countries_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **str**|  | 

### Return type

[**list[CountryDto]**](CountryDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

