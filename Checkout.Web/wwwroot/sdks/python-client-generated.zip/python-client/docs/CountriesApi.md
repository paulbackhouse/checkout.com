# swagger_client.CountriesApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_vversion_countries_by_country_id_get**](CountriesApi.md#api_vversion_countries_by_country_id_get) | **GET** /api/v{version}/Countries/{countryId} | 
[**api_vversion_countries_get**](CountriesApi.md#api_vversion_countries_get) | **GET** /api/v{version}/Countries | 


# **api_vversion_countries_by_country_id_get**
> CountryDto api_vversion_countries_by_country_id_get(country_id, version)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CountriesApi()
country_id = 56 # int | 
version = 'version_example' # str | 

try:
    api_response = api_instance.api_vversion_countries_by_country_id_get(country_id, version)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CountriesApi->api_vversion_countries_by_country_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **country_id** | **int**|  | 
 **version** | **str**|  | 

### Return type

[**CountryDto**](CountryDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_vversion_countries_get**
> list[CountryDto] api_vversion_countries_get(version)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CountriesApi()
version = 'version_example' # str | 

try:
    api_response = api_instance.api_vversion_countries_get(version)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CountriesApi->api_vversion_countries_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **str**|  | 

### Return type

[**list[CountryDto]**](CountryDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

