# CountryDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | 
**iso_code** | **str** |  | 
**currency_symbol** | **str** |  | [optional] 
**currency** | **str** |  | [optional] 
**tax** | **float** |  | [optional] 
**tax_formatted** | **str** |  | [optional] 
**is_default** | **bool** |  | [optional] 
**is_active** | **bool** |  | [optional] 
**id** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


