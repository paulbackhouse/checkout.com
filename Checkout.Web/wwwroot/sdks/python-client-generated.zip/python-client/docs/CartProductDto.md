# CartProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**country_iso_code** | **str** |  | [optional] 
**net_price** | **float** |  | [optional] 
**total_net_price** | **float** |  | [optional] 
**total_net_price_formatted** | **str** |  | [optional] 
**tax_amount** | **float** |  | [optional] 
**tax_amount_formatted** | **str** |  | [optional] 
**total_tax** | **float** |  | [optional] 
**total_tax_formatted** | **str** |  | [optional] 
**total_gross_price** | **float** |  | [optional] 
**total_gross_price_formatted** | **str** |  | [optional] 
**cart_id** | **str** |  | [optional] 
**country_id** | **int** |  | [optional] 
**product_id** | **int** |  | [optional] 
**qty** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


