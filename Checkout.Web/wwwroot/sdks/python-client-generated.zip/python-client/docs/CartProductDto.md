# CartProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product_name** | **str** |  | [optional] 
**product_code** | **str** |  | [optional] 
**country_iso_code** | **str** |  | [optional] 
**net_price** | **float** |  | [optional] 
**total_net_price** | **float** |  | [optional] 
**total_net_price_formatted** | **str** |  | [optional] 
**tax_amount** | **float** |  | [optional] 
**tax_amount_formatted** | **str** |  | [optional] 
**total_tax** | **float** |  | [optional] 
**total_tax_formatted** | **str** |  | [optional] 
**total_gross_price** | **float** |  | [optional] 
**total_gross_price_formatted** | **str** |  | [optional] 
**cart_id** | **str** | Unique Id of an existing cart to update.   When empty a new cart is create (Guid.Empty &#x3D; 00000000-0000-0000-0000-000000000000) | [optional] 
**country_id** | **int** | Country the cart item relates to | [optional] 
**product_id** | **int** | Cart item (product) to add/update | [optional] 
**qty** | **int** | the quantity to add/update for a given cart item (product) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


