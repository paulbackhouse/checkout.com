# CartDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cart_id** | **str** |  | [optional] 
**country_id** | **int** |  | [optional] 
**country_iso_code** | **str** |  | [optional] 
**items** | [**list[CartProductDto]**](CartProductDto.md) |  | [optional] 
**total_net_price** | **float** |  | [optional] 
**total_net_price_formatted** | **str** |  | [optional] 
**total_tax** | **float** |  | [optional] 
**total_tax_formatted** | **str** |  | [optional] 
**total_gross_price** | **float** |  | [optional] 
**total_gross_price_formatted** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


