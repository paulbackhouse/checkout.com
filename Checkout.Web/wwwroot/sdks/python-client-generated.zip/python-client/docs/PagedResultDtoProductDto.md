# PagedResultDtoProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**list[ProductDto]**](ProductDto.md) |  | [optional] 
**pager** | [**PagerDto**](PagerDto.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


