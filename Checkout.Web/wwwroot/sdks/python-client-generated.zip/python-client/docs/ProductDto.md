# ProductDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **str** |  | 
**short_description** | **str** |  | 
**net_price** | **float** |  | [optional] 
**net_price_formatted** | **str** |  | [optional] 
**country** | [**CountryDto**](CountryDto.md) |  | 
**tax_amount** | **float** |  | [optional] 
**tax_amount_formatted** | **str** |  | [optional] 
**id** | **int** |  | [optional] 
**name** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


