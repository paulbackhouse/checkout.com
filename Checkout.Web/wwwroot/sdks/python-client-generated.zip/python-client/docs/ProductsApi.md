# swagger_client.ProductsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_vversion_products_by_country_id_get**](ProductsApi.md#api_vversion_products_by_country_id_get) | **GET** /api/v{version}/Products/{countryId} | 
[**api_vversion_products_by_product_id_get**](ProductsApi.md#api_vversion_products_by_product_id_get) | **GET** /api/v{version}/Products/{productId} | 


# **api_vversion_products_by_country_id_get**
> list[ProductDto] api_vversion_products_by_country_id_get(country_id, version, page_index=page_index, page_size=page_size)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ProductsApi()
country_id = 56 # int | 
version = 'version_example' # str | 
page_index = 56 # int |  (optional)
page_size = 56 # int |  (optional)

try:
    api_response = api_instance.api_vversion_products_by_country_id_get(country_id, version, page_index=page_index, page_size=page_size)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductsApi->api_vversion_products_by_country_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **country_id** | **int**|  | 
 **version** | **str**|  | 
 **page_index** | **int**|  | [optional] 
 **page_size** | **int**|  | [optional] 

### Return type

[**list[ProductDto]**](ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_vversion_products_by_product_id_get**
> ProductDto api_vversion_products_by_product_id_get(product_id, version)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ProductsApi()
product_id = 56 # int | 
version = 'version_example' # str | 

try:
    api_response = api_instance.api_vversion_products_by_product_id_get(product_id, version)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductsApi->api_vversion_products_by_product_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_id** | **int**|  | 
 **version** | **str**|  | 

### Return type

[**ProductDto**](ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

