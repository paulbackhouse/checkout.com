# swagger_client.ProductsApi

All URIs are relative to *https://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_vversion_products_by_product_id_get**](ProductsApi.md#api_vversion_products_by_product_id_get) | **GET** /api/v{version}/Products/{productId} | Gets a product by a given productId
[**api_vversion_products_get**](ProductsApi.md#api_vversion_products_get) | **GET** /api/v{version}/Products | Gets a collection of products available for a given countryId


# **api_vversion_products_by_product_id_get**
> ProductDto api_vversion_products_by_product_id_get(product_id, version)

Gets a product by a given productId

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ProductsApi()
product_id = 56 # int | Id to query for
version = 'version_example' # str | 

try:
    # Gets a product by a given productId
    api_response = api_instance.api_vversion_products_by_product_id_get(product_id, version)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductsApi->api_vversion_products_by_product_id_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_id** | **int**| Id to query for | 
 **version** | **str**|  | 

### Return type

[**ProductDto**](ProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_vversion_products_get**
> PagedResultDtoProductDto api_vversion_products_get(version, country_id=country_id, page_index=page_index, page_size=page_size)

Gets a collection of products available for a given countryId

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ProductsApi()
version = 'version_example' # str | 
country_id = 56 # int | Required. A countryId to request products for (optional)
page_index = 56 # int | Zero based index querystring parameter requesting page. i.e first page = 0 (optional)
page_size = 56 # int | Page size querystring parameter required (optional)

try:
    # Gets a collection of products available for a given countryId
    api_response = api_instance.api_vversion_products_get(version, country_id=country_id, page_index=page_index, page_size=page_size)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ProductsApi->api_vversion_products_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **version** | **str**|  | 
 **country_id** | **int**| Required. A countryId to request products for | [optional] 
 **page_index** | **int**| Zero based index querystring parameter requesting page. i.e first page &#x3D; 0 | [optional] 
 **page_size** | **int**| Page size querystring parameter required | [optional] 

### Return type

[**PagedResultDtoProductDto**](PagedResultDtoProductDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json;v=1.0

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

